import pygame
import sys
import random
import os

if os.path.exists("_internal"):
    os.chdir("_internal")

# Initialize clock
pygame_clock = pygame.time.Clock()
start_ticks = pygame.time.get_ticks()  # Starter tick

# Initialize Pygame
pygame.init()

# Colors
black = (0, 0, 0)
yellow = (255, 255, 0)
blue = (0, 0, 255)
red = (255, 0, 0)
white = (255, 255, 255)

# Pac-Man settings
pacman_radius = 15
movement_speed = 5

ghost_white_time = 5000  # Time in milliseconds for the ghost to be white after eating a power pellet
ghost_eaten_time = 3000  # Time in milliseconds for the ghost to be eaten
god_mode_time = 5000  # Time in milliseconds for God Mode

# Wall settings
wall_thickness = 20
gate_width = 50  # Width of the gate
corridor_width = 6 * pacman_radius
tile_side = corridor_width + 1 * wall_thickness

# Play background music
pygame.mixer.music.load('sounds/theme.mp3')
pygame.mixer.music.play(-1)

maze_walls = []
max_x = 0
with open('mazes/maze.txt', 'r', encoding='utf-8') as file:  # https://asciiflow.com/legacy/
    y = 0
    for line in file:
        x = 0
        for char in line:
            if char == '\n':
                break
            elif char == '@':
                pacman_x, pacman_y = x, y
            elif char == 'U':
                ghost_x, ghost_y = x, y
            elif char != ' ':
                maze_walls.append(pygame.Rect(x, y, wall_thickness, wall_thickness))
            x += wall_thickness
        if x > max_x:
            max_x = x
        y += wall_thickness

# Screen dimensions
screen_width = max_x
screen_height = y

# Set up the display
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Pac-Man in Pygame")

def will_collide_with_walls(next_rect, walls):
    for wall in walls:
        if next_rect.colliderect(wall):
            return True
    return False

# Ghost settings
ghost_color = red
ghost_radius = pacman_radius

# Dot settings
dot_radius = 5
# Initialize dots
dots = []
for x in range(wall_thickness * 2, screen_width - wall_thickness * 2, wall_thickness * 2):
    for y in range(wall_thickness * 2, screen_height - wall_thickness * 2, wall_thickness * 2):
        dot_rect = pygame.Rect(x - dot_radius + wall_thickness, y - dot_radius + wall_thickness, dot_radius * 2, dot_radius * 2)
        if not will_collide_with_walls(dot_rect, maze_walls):
            dots.append(dot_rect)

dots_original = dots.copy()

power_pellet_radius = 10
power_pellet = None

def create_power_pellet():
    while True:
        chosen_dot = random.choice(dots_original)
        power_pellet_x, power_pellet_y = chosen_dot.center
        power_pellet_rect = pygame.Rect(
            power_pellet_x - power_pellet_radius,
            power_pellet_y - power_pellet_radius,
            power_pellet_radius * 2,
            power_pellet_radius * 2
        )
        if not will_collide_with_walls(power_pellet_rect, maze_walls) and not power_pellet_rect.colliderect(pygame.Rect(pacman_x - pacman_radius, pacman_y - pacman_radius, pacman_radius * 2, pacman_radius * 2)):
            return power_pellet_rect

power_pellet = create_power_pellet()

directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
last_direction = random.choice(directions)

def random_walk_ghost(ghost_x_pos, ghost_y_pos, walls, last_dir):
    change_direction_prob = 0.01  # Probability to change direction at random
    new_dir = last_dir
    next_ghost_rect = pygame.Rect(
        ghost_x_pos + last_dir[0] * movement_speed - ghost_radius,
        ghost_y_pos + last_dir[1] * movement_speed - ghost_radius,
        ghost_radius * 2,
        ghost_radius * 2)

    if will_collide_with_walls(next_ghost_rect, walls) or random.random() < change_direction_prob:
        dir_options = directions.copy()
        dir_options.remove((last_dir[0], last_dir[1]))
        while dir_options:
            new_dir = random.choice(dir_options)
            next_ghost_rect = pygame.Rect(
                ghost_x_pos + new_dir[0] * movement_speed - ghost_radius,
                ghost_y_pos + new_dir[1] * movement_speed - ghost_radius,
                ghost_radius * 2,
                ghost_radius * 2)
            if not will_collide_with_walls(next_ghost_rect, walls):
                break
            dir_options.remove(new_dir)

    ghost_x_pos += new_dir[0] * movement_speed
    ghost_y_pos += new_dir[1] * movement_speed

    # Prevent Ghost from moving outside the screen
    ghost_x_pos = max(ghost_radius, min(screen_width - ghost_radius, ghost_x_pos))
    ghost_y_pos = max(ghost_radius, min(screen_height - ghost_radius, ghost_y_pos))

    return ghost_x_pos, ghost_y_pos, new_dir

# Game loop flag
running = True

ghost_is_eaten = False
ghost_revival_time = 0

# God Mode variables
god_mode = False
god_mode_end_time = 0

# Score tracking
score = 0

def get_score():
    """Returns the current score."""
    return score

def game_over_screen(score, timer):
    screen.fill(black)
    font = pygame.font.SysFont('Comic Sans MS', 30)
    text = font.render(f'Game Over', True, white)
    score_text = font.render(f'Score: {score}', True, white)
    timer_text = font.render(f'Time Alive: {timer // 1000}', True, white)
    screen.blit(text, (screen_width // 2 - text.get_width() // 2, screen_height // 3))
    screen.blit(score_text, (screen_width // 2 - score_text.get_width() // 2, screen_height // 2))
    screen.blit(timer_text, (screen_width // 2 - timer_text.get_width() // 2, screen_height // 2 + score_text.get_height()))
    pygame.display.update()
    pygame.time.wait(5000)

# Main game loop
while running:
    current_time = pygame.time.get_ticks()

    if current_time > ghost_revival_time:
        ghost_is_eaten = False
        ghost_color = red

    if current_time > god_mode_end_time:
        god_mode = False

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Movement handling
    keys = pygame.key.get_pressed()
    dx, dy = 0, 0
    if keys[pygame.K_LEFT]:
        dx = -movement_speed
    if keys[pygame.K_RIGHT]:
        dx = movement_speed
    if keys[pygame.K_UP]:
        dy = -movement_speed
    if keys[pygame.K_DOWN]:
        dy = movement_speed

    # Create a temporary rect to test the new position
    temp_rect = pygame.Rect(pacman_x + dx - pacman_radius, pacman_y + dy - pacman_radius, pacman_radius * 2, pacman_radius * 2)

    # Check for potential collisions only if not in God Mode
    if not god_mode and will_collide_with_walls(temp_rect, maze_walls):
        dx, dy = 0, 0

    pacman_x += dx
    pacman_y += dy

    # Prevent Pac-Man from moving outside the screen
    pacman_x = max(pacman_radius, min(screen_width - pacman_radius, pacman_x))
    pacman_y = max(pacman_radius, min(screen_height - pacman_radius, pacman_y))

    # Screen update
    screen.fill(black)

    # Draw walls
    for wall_rect in maze_walls:
        pygame.draw.rect(screen, blue, wall_rect)

    # Define pacman_rect before using it
    pacman_rect = pygame.Rect(pacman_x - pacman_radius, pacman_y - pacman_radius, pacman_radius * 2, pacman_radius * 2)

    # Draw dots
    for dot in dots[:]:
        if pacman_rect.colliderect(dot):
            dots.remove(dot)
            score += 10  # Add score for eating a dot
        else:
            pygame.draw.circle(screen, white, dot.center, dot_radius)

    # Draw Pac-Man
    pygame.draw.circle(screen, yellow, pacman_rect.center, pacman_radius)

    # Check for collision with power pellet
    if pacman_rect.colliderect(power_pellet):
        power_pellet = create_power_pellet()
        ghost_is_eaten = True
        ghost_color = white
        ghost_revival_time = pygame.time.get_ticks() + ghost_white_time

        # Activate God Mode
        god_mode = True
        god_mode_end_time = pygame.time.get_ticks() + god_mode_time

        # Adjust score
        score += 100  # Add 100 points for eating the red power
# pellet

    # Draw Pac-Man's eye
    eye_x, eye_y = pacman_x, pacman_y
    if dy < 0:  # Pac-Man moving up
        eye_x = pacman_x + pacman_radius * 0.4
        eye_y = pacman_y - pacman_radius * 0.6
    elif dy > 0:  # Pac-Man moving down
        eye_x = pacman_x + pacman_radius * 0.4
        eye_y = pacman_y + pacman_radius * 0.6
    elif dx < 0:  # Pac-Man moving left
        eye_x = pacman_x - pacman_radius * 0.6
        eye_y = pacman_y - pacman_radius * 0.4
    else:  # Pac-Man moving right
        eye_x = pacman_x + pacman_radius * 0.6
        eye_y = pacman_y - pacman_radius * 0.4

    pygame.draw.circle(screen, black, (eye_x, eye_y), 5)

    # Draw power pellet
    pygame.draw.circle(screen, red, power_pellet.center, power_pellet_radius)

    # Move ghost randomly
    ghost_x, ghost_y, last_direction = random_walk_ghost(ghost_x, ghost_y, maze_walls, last_direction)

    # Draw ghost
    ghost_rect = pygame.Rect(ghost_x - ghost_radius, ghost_y - ghost_radius, ghost_radius * 2, ghost_radius * 2)
    pygame.draw.circle(screen, ghost_color, ghost_rect.center, ghost_radius)

    # Check for collision with ghost
    if pacman_rect.colliderect(ghost_rect):
        if ghost_is_eaten:
            ghost_x, ghost_y = pacman_x, pacman_y  # Move ghost to Pac-Man's position temporarily
            ghost_is_eaten = False
            ghost_color = red
            ghost_revival_time = pygame.time.get_ticks() + ghost_eaten_time
            score += 200  # Add score for eating the ghost
        else:
            running = False

    # Timer
    timer = pygame.time.get_ticks() - start_ticks  # Calculate how many seconds
    font = pygame.font.SysFont('Comic Sans MS', 30)
    text = font.render(f'Time: {timer // 1000}  Score: {get_score()}', False, (255, 255, 255))
    screen.blit(text, (0, 0))

    pygame.display.update()
    pygame_clock.tick(60)

game_over_screen(score, timer)
