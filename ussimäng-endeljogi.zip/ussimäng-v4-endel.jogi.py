import pygame
import time
import random
from pygame.locals import *

pygame.init()

# Värvid
white = (255, 255, 255)
yellow = (255, 255, 102)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)
blue = (50, 153, 213)

# Lisatakse rohkem värve ussile
snake_colors = [red, green, blue, yellow]
current_color_index = 0

# Ekraani mõõtmed
dis_width = 1080
dis_height = 1080

# Ekraani seadistamine
dis = pygame.display.set_mode((dis_width, dis_height))
pygame.display.set_caption('Ussimäng')

clock = pygame.time.Clock()

# Ussi ploki suurus ja algkiirus
snake_block = 20  # Suurendab ussi ploki suurust
initial_snake_speed = 15
snake_speed = initial_snake_speed

# Fondid
font_style = pygame.font.SysFont("bahnschrift", 45)
score_font = pygame.font.SysFont("comicsansms", 45)

# Laaditakse pildid
fruit_images = {
    "apple": pygame.image.load("apple.png"),
    "banana": pygame.image.load("banana.png"),
    "cherry": pygame.image.load("cherry.png"),
}

# Piltide suuruse muutmine
fruit_size = (int(snake_block * 2), int(snake_block * 2))  # Kohandab vilja suurust uue ussi ploki suuruse järgi
for fruit_name in fruit_images:
    fruit_images[fruit_name] = pygame.transform.scale(fruit_images[fruit_name], fruit_size)

# Laaditakse helid
pygame.mixer.music.load("background_music.mp3")
pygame.mixer.music.play(-1)  # Taustamuusika kordamine
fruit_collect_sound = pygame.mixer.Sound("collect_sound.mp3")
death_sound = pygame.mixer.Sound("death_sound.mp3")
final_music = pygame.mixer.Sound("final_music.mp3")

# Võrgustiku joonistamise funktsioon
def draw_grid():
    for x in range(0, dis_width, snake_block):
        for y in range(0, dis_height, snake_block):
            rect = pygame.Rect(x, y, snake_block, snake_block)
            pygame.draw.rect(dis, (200, 200, 200), rect, 1)

# Skoori kuvamine
def Your_score(score):
    value = score_font.render("Score: " + str(score), True, black)
    dis.blit(value, [0, 0])

# Ussi joonistamine
def our_snake(snake_block, snake_list, color):
    for x in snake_list:
        pygame.draw.rect(dis, color, [x[0], x[1], snake_block, snake_block])

# Sõnumi kuvamine
def message(msg, color):
    mesg = font_style.render(msg, True, color)
    text_rect = mesg.get_rect(center=(dis_width / 2, dis_height / 2))
    dis.blit(mesg, text_rect)

# Puuvilja genereerimine
def generate_fruit():
    fruit = random.choice(list(fruit_images.keys()))
    x = round(random.randrange(0, dis_width - fruit_size[0]) / 10.0) * 10.0
    y = round(random.randrange(0, dis_height - fruit_size[1]) / 10.0) * 10.0
    return fruit, x, y

# Taimeri kuvamine
def display_timer(seconds):
    timer_text = score_font.render(f"Time: {seconds}", True, black)
    dis.blit(timer_text, [dis_width - 200, 0])

# Kõikide helide peatamine
def stop_all_sounds():
    pygame.mixer.music.stop()
    for sound in [fruit_collect_sound, death_sound, final_music]:
        sound.stop()

# Mängu tsükkel
def gameLoop():
    global snake_speed, current_color_index
    game_over = False
    game_close = False
    played_death_sound = False
    played_final_music = False

    # Taustamuusika taaskäivitamine
    pygame.mixer.music.play(-1)

    x1 = dis_width / 2
    y1 = dis_height / 2

    x1_change = 0
    y1_change = 0

    snake_List = []
    Length_of_snake = 1

    fruits = [generate_fruit() for _ in range(5)]

    start_time = pygame.time.get_ticks()
    last_speed_increase_time = start_time
    last_color_change_time = start_time

    while not game_over:

        while game_close:
            if not played_death_sound:
                pygame.mixer.Sound.play(death_sound)
                played_death_sound = True

            if not played_final_music and played_death_sound:
                pygame.mixer.music.stop()
                pygame.mixer.Sound.play(final_music)
                played_final_music = True

            dis.fill(black)
            message("You died! ESC-exit, Any key to play again", red)
            Your_score(Length_of_snake - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        game_over = True
                        game_close = False
                    else:
                        stop_all_sounds()
                        snake_speed = initial_snake_speed
                        gameLoop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and x1_change == 0:
                    x1_change = -snake_block
                    y1_change = 0
                elif event.key == pygame.K_RIGHT and x1_change == 0:
                    x1_change = snake_block
                    y1_change = 0
                elif event.key == pygame.K_UP and y1_change == 0:
                    y1_change = -snake_block
                    x1_change = 0
                elif event.key == pygame.K_DOWN and y1_change == 0:
                    y1_change = snake_block
                    x1_change = 0

        if x1 >= dis_width or x1 < 0 or y1 >= dis_height or y1 < 0:
            game_close = True
        x1 += x1_change
        y1 += y1_change
        dis.fill(white)
        draw_grid()
        for fruit, fruitx, fruity in fruits:
            dis.blit(fruit_images[fruit], (fruitx, fruity))
        snake_Head = []
        snake_Head.append(x1)
        snake_Head.append(y1)
        snake_List.append(snake_Head)
        if len(snake_List) > Length_of_snake:
            del snake_List[0]

        for x in snake_List[:-1]:
            if x == snake_Head:
                game_close = True

        current_time = pygame.time.get_ticks()
        elapsed_time = (current_time - start_time) // 1000
        display_timer(elapsed_time)

        # Muudab ussi värvi iga 10 sekundi tagant
        if current_time - last_color_change_time >= 10000:
            current_color_index = (current_color_index + 1) % len(snake_colors)
            last_color_change_time = current_time

        our_snake(snake_block, snake_List, snake_colors[current_color_index])
        Your_score(Length_of_snake - 1)

        if current_time - last_speed_increase_time >= 10000:
            snake_speed += 1
            last_speed_increase_time = current_time

        pygame.display.update()

        for i, (fruit, fruitx, fruity) in enumerate(fruits):
            fruit_rect = pygame.Rect(fruitx, fruity, fruit_size[0], fruit_size[1])
            snake_head_rect = pygame.Rect(x1, y1, snake_block, snake_block)
            if snake_head_rect.colliderect(fruit_rect):
                fruits[i] = generate_fruit()
                Length_of_snake += 1
                pygame.mixer.Sound.play(fruit_collect_sound)

        clock.tick(snake_speed)

    pygame.quit()
    quit()

gameLoop()

