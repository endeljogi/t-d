import pygame
import math

pygame.init()

# Screen settings
screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("LUMEMEMM")

# Light blue background
screen.fill([173, 216, 230])

# Snowman
pygame.draw.circle(screen, [255, 255, 255], [150,67], 30, 0)
pygame.draw.circle(screen, [255, 255, 255], [150,125], 40, 0)
pygame.draw.circle(screen, [255, 255, 255], [150,200], 50, 0)

# Eyes and nose
pygame.draw.circle(screen, [0, 0, 0], [140,57], 5, 0)
pygame.draw.circle(screen, [0, 0, 0], [160,57], 5, 0)
pygame.draw.polygon(screen, [255, 153, 51], [[150,77],[147,63],[153,63]], 0)

# Buttons
pygame.draw.circle(screen, [0, 0, 0], [150,105], 5, 0)
pygame.draw.circle(screen, [0, 0, 0], [150,125], 5, 0)
pygame.draw.circle(screen, [0, 0, 0], [150,145], 5, 0)

# Arms
pygame.draw.line(screen, [139, 69, 19], [120, 120], [100, 100], 5)
pygame.draw.line(screen, [139, 69, 19], [180, 120], [200, 100], 5)

# Hat
pygame.draw.rect(screen, [0, 0, 0], [125, 25, 50, 30], 0)
pygame.draw.rect(screen, [0, 0, 0], [110, 45, 80, 10], 0)

# hari
pygame.draw.line(screen, [153, 51, 0], [100,100], [50,200], 7)

pygame.draw.line(screen, [255, 255, 128], [50,200], [25,220], 5)
pygame.draw.line(screen, [255, 255, 128], [50,200],[60,240], 5)
pygame.draw.line(screen, [255, 255, 128], [50,200], [15,225], 5)
pygame.draw.line(screen, [255, 255, 128], [50,200], [13,200], 5)
pygame.draw.line(screen, [255, 255, 128], [50,200], [30,230], 5)
# Sun with rays
pygame.draw.circle(screen, [255, 255, 0], [270, 50], 25, 0)
for i in range(0, 360, 45):
    x1 = 270 + 25 * math.cos(math.radians(i))
    y1 = 50 + 25 * math.sin(math.radians(i))
    x2 = 270 + 50 * math.cos(math.radians(i))
    y2 = 50 + 50 * math.sin(math.radians(i))
    pygame.draw.line(screen, [255, 255, 0], [x1, y1], [x2, y2], 3)

# Clouds
pygame.draw.circle(screen, [255, 255, 255], [10, 40], 20, 0)
pygame.draw.circle(screen, [255, 255, 255], [40, 20], 20, 0)
pygame.draw.circle(screen, [255, 255, 255], [70, 40], 20, 0)

pygame.draw.circle(screen, [255, 255, 255], [200, 20], 20, 0)
pygame.draw.circle(screen, [255, 255, 255], [230, 20], 20, 0)
pygame.draw.circle(screen, [255, 255, 255], [260, 20], 20, 0)

pygame.draw.circle(screen, [255, 255, 255], [10, 100], 20, 0)
pygame.draw.circle(screen, [255, 255, 255], [40, 90], 20, 0)
pygame.draw.circle(screen, [255, 255, 255], [70, 100], 20, 0)

# Update display
pygame.display.flip()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
