import pygame
pygame.init()

# Screen settings
screen = pygame.display.set_mode([300, 600])
pygame.display.set_caption("valgusfoor-endel.jogi")

# Draw the traffic light
pygame.draw.rect(screen, [140, 140, 140], [101, 17, 100, 250], 2)
pygame.draw.circle(screen, [255, 0, 0], [150, 58], 40, 0)
pygame.draw.circle(screen, [255, 255, 0], [150, 140], 40, 0)
pygame.draw.circle(screen, [102, 255, 51], [150, 222], 40, 0)

# Draw the post
pygame.draw.rect(screen, [140, 140, 140], [140, 264, 25, 300], 2)

# Draw the post base
post_base_points = [(152, 564), (120, 600), (175, 600)]
pygame.draw.polygon(screen, [0, 0, 255], post_base_points, 0)

# Update display
pygame.display.flip()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
