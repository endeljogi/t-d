import pygame
pygame.init()
#ekraani seaded
screen=pygame.display.set_mode([640,480])
pygame.display.set_caption("Ülesanne 2")


#Lisame pildid
bg = pygame.image.load("bg_shop.jpg")
screen.blit(bg,[0,0])

seller = pygame.image.load("seller.png")
seller = pygame.transform.scale(seller, [224, 264])
screen.blit(seller,[140,180])

chat = pygame.image.load("chat.png")
chat = pygame.transform.scale(chat, [250, 190])
screen.blit(chat,[260,75])

#lisame teksti
font = pygame.font.Font(None, 25)
text = font.render("Tere, olen Endel Jõgi", True, [255,255,255])
screen.blit(text, [280,150])




#vikk logo
vikk = pygame.image.load("vikk.png")
vikk = pygame.transform.scale(vikk, [267, 35])
screen.blit(vikk,[0,0])

#mõõk
mõõk = pygame.image.load("Mõõk.png")
mõõk = pygame.transform.scale(mõõk, [100, 82])
screen.blit(mõõk,[530,180])

#tort
tort = pygame.image.load("tort.png")
tort = pygame.transform.scale(tort, [100, 82])
screen.blit(tort,[400,215])


# Lisame kaarega teksti "TULEVIK 2050"
font = pygame.font.Font(None, 30)
text = font.render("TULEVIK 2050", True, [255, 255, 255])
text = pygame.transform.rotate(text, 45)
screen.blit(text, [50, 50])






pygame.display.flip()

running = True
try:
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
    pygame.quit()
except SystemExit:
    pygame.quit()
