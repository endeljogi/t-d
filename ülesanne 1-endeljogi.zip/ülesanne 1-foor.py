import pygame
pygame.init()

# Screen settings
screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("valgusfoor-endel.jogi")

pygame.draw.rect(screen, [140, 140, 140], [101, 17, 100, 250], 2)
pygame.draw.circle(screen, [255, 0, 0], [150,58], 40, 0)
pygame.draw.circle(screen, [255, 255, 0], [150,140], 40,0)
pygame.draw.circle(screen, [102, 255, 51], [150,222], 40, 0)
# Update display
pygame.display.flip()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()