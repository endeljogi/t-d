import pygame
pygame.init()

# Screen settings
screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("lumememm-endel.jogi")

pygame.draw.circle(screen, [255, 255, 255], [150,67], 30, 0)
pygame.draw.circle(screen, [255, 255, 255], [150,125], 40,0)
pygame.draw.circle(screen, [255, 255, 255], [150,200], 50, 0)

pygame.draw.circle(screen, [0, 0, 0], [140,57], 5, 0)
pygame.draw.circle(screen, [0, 0, 0], [160,57], 5,0)
pygame.draw.polygon(screen, [255, 153, 51], [[150,77],[147,63],[153,63]], 0)
# Update display
pygame.display.flip()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()


