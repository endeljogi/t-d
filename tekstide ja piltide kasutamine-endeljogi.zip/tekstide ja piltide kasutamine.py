import pygame
pygame.init()

# Screen settings
screen = pygame.display.set_mode([640,480])
pygame.display.set_caption("Harjutamine")
screen.fill([204, 255, 204])

# Adding text
font = pygame.font.Font(None, 30)  # Using default font with size 30
text = font.render("Hello PyGame", True, [0, 0, 0])
screen.blit(text, [200, 200])

# Using Arial font with size 50
font = pygame.font.Font(pygame.font.match_font('arial'), 50)
text = font.render("Hello PyGame", True, [0, 0, 0])

# Text box size
text_rect = text.get_rect(center=(320, 240))  # Centering the text
screen.blit(text, text_rect)

# Updating display
pygame.display.flip()

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
